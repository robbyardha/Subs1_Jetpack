package com.ardhacodes.subs1_jetpack.ui

import com.ardhacodes.subs1_jetpack.data.MovieTvEntity

interface CallbackMovTv {
    fun onItemClicked(movtvEntity : MovieTvEntity)
}