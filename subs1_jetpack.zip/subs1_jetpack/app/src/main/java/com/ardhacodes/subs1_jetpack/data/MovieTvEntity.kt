package com.ardhacodes.subs1_jetpack.data

data class MovieTvEntity(
    var id : String,
    var title : String,
    var genre : String,
    var yearrelease : String,
    var poster : String,
    var score : String,
    var duration: String,
    var overview: String,
)
